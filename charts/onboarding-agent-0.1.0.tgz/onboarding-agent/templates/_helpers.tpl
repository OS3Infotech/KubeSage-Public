{{/*
Validate that required values are supplied via --set (or values file)
*/}}
{{- define "requiredValues" -}}
  {{- if not .Values.clusterName -}}
    {{- fail "clusterName is REQUIRED. Use --set clusterName=..." -}}
  {{- end -}}
  {{- if not .Values.username -}}
    {{- fail "username is REQUIRED. Use --set username=..." -}}
  {{- end -}}
  {{- if not .Values.prometheusUrl -}}
    {{- fail "prometheusUrl is REQUIRED. Use --set prometheusUrl=..." -}}
  {{- end -}}
  {{- if not .Values.lokiUrl -}}
    {{- fail "lokiUrl is REQUIRED. Use --set lokiUrl=..." -}}
  {{- end -}}
  {{- if not .Values.backendHost -}}
    {{- fail "backendHost is REQUIRED. Use --set backendHost=..." -}}
  {{- end -}}
  {{- if not .Values.providerName -}}
    {{- fail "providerName is REQUIRED. Use --set providerName=..." -}}
  {{- end -}}
  {{- if not .Values.agentId -}}
    {{- fail "agentId is REQUIRED. Use --set agentId=..." -}}
  {{- end -}}
  {{- if not .Values.apiKey -}}
    {{- fail "apiKey is REQUIRED. Use --set apiKey=..." -}}
  {{- end -}}
  {{- if not .Values.tags -}}
    {{- fail "tags is REQUIRED. Use --set tags='{prod,dev}'" -}}
  {{- end -}}
{{- end -}}
